import './App.css';
import Chat from './components/Chat';
import SignIn from './components/SignIn';
import { auth } from './firebase'
import { useAuthState } from 'react-firebase-hooks/auth'

function App() {
  const [user] = useAuthState(auth)
  return (
    <>
      {user ? <Chat /> : <SignIn />}
    </>
  );
}

export default App;
















// import './App.css';
// import Chat from './components/Chat';
// import SignIn from './components/SignIn';

// function App() {
//   return (
//     <div className="App">
//       <SignIn />
//       <Chat />
//     </div>
//   );
// }

// export default App;
